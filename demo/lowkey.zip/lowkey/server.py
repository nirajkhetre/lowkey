"""The local dashboard and its JSON API. Binds to 127.0.0.1 only, and only answers this machine's own pages."""
import json
import re
import socket
import sys
import time
from datetime import datetime, timedelta
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import focus
from .config import CONFIG, DATA, DEMO, LIVE, MODEL, PERSONAL, PORT, load, lock, save, save_config, update_settings
from .labeler import (WAKE, add_manual, brief, day_sessions, delete_manual, life, life_week, model_ok, rename_client,
                      reviewed, suggest_hint, teach)

WEB = Path(__file__).parent / "web"
STATUSES = ("pending", "billed", "nah")


def nums(v, n):
    """Exactly n finite numbers of a sane size (screen coordinates from the page), or None."""
    try:
        out = [float(x) for x in v]
    except (TypeError, ValueError):
        return None
    return out if len(out) == n and all(abs(x) < 1e5 for x in out) else None


def clean_config(e):
    """Your profile and clients from the dashboard, checked: unique names (Personal is reserved), sane rates, hex
    colours, and hints of 3+ characters (a hint like "a" would match every window)."""
    me, out = e.get("me") or {}, {}
    for k, n in (("name", 60), ("email", 80), ("currency", 3)):
        if k in me:
            out[k] = str(me[k]).strip()[:n]
    if "daily_goal_h" in me:
        g = float(me["daily_goal_h"])
        if not 0 < g <= 16:
            raise ValueError("goal")
        out["daily_goal_h"] = int(g) if g == int(g) else g
    clients, seen = [], set()
    for c in e["clients"][:50]:
        name = str(c["name"]).strip()[:40]
        if not name or name.lower() in seen or name.lower() == PERSONAL.lower():
            raise ValueError("name")
        seen.add(name.lower())
        rate = float(c.get("rate") or 0)
        if not 0 <= rate <= 1e6:
            raise ValueError("rate")
        hints = [h for h in (str(h).strip()[:40] for h in (c.get("hints") or [])) if len(h) >= 3][:20]
        clients.append({"name": name, "rate": int(rate) if rate == int(rate) else rate, "hints": hints,
                        "color": c["color"] if re.fullmatch(r"#[0-9a-fA-F]{6}", str(c.get("color"))) else "#7AA2FF"})
    names = {c["name"] for c in clients}
    renames = {str(o): str(n) for o, n in (e.get("renames") or {}).items() if str(n) in names and str(o) != str(n)}
    return out, clients, renames


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(WEB), **kw)

    def log_message(self, *a):
        pass

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")  # always revalidate, so an update never shows yesterday's UI
        super().end_headers()

    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def body(self):
        return json.loads(self.raw)

    def allowed(self):
        """Only this machine's own pages get an answer. A foreign Host header means DNS rebinding (a website
        pretending to be localhost to read your activity); a foreign Origin means some site in your browser is
        trying to drive lowkey. Both get a 403."""
        port = self.server.server_address[1]
        hosts = {f"127.0.0.1:{port}", f"localhost:{port}", f"[::1]:{port}"}
        origin = self.headers.get("Origin")
        if self.headers.get("Host") in hosts and (not origin or origin.removeprefix("http://") in hosts):
            return True
        self.send_json({"error": "forbidden"}, 403)
        return False

    def guard(self, route):
        try:
            route()
        except (ValueError, KeyError, TypeError, AttributeError) as e:  # bad JSON, missing fields, wrong types
            self.send_json({"error": f"bad request ({e.__class__.__name__})"}, 400)

    def do_GET(self):
        if self.allowed():
            self.guard(self.get)

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0) if (self.headers.get("Content-Length") or "0").isdigit() else -1
        if not 0 <= n <= 1 << 20:
            return self.send_json({"error": "bad length"}, 413)
        self.raw = self.rfile.read(n)  # read it all before any answer: replying over unread bytes resets the connection
        if not self.allowed():
            return
        if not (self.headers.get("Content-Type") or "").startswith("application/json"):
            return self.send_json({"error": "send JSON"}, 415)  # also makes browsers preflight, which we never allow
        self.guard(self.post)

    def get(self):
        url = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(url.query).items()}
        if url.path == "/api/state":
            days = sorted(p.stem[9:] for p in DATA.glob("activity-*.jsonl"))
            return self.send_json({"config": CONFIG, "model": MODEL, "model_ok": model_ok(), "demo": DEMO, "days": days})
        if url.path == "/api/settings":
            return self.send_json({"settings": LIVE["settings"], "taskbar": LIVE.get("taskbar"),
                                   "platform": sys.platform, "island": not DEMO,
                                   "slot_today": LIVE.get("slot_today", LIVE["settings"].get("slot")),
                                   "slot_locked": not DEMO and reviewed(datetime.now().strftime("%Y-%m-%d"))})
        if url.path == "/api/pulse":  # cheap and polled: is the model working right now, and is there anything new
            return self.send_json({"thinking": LIVE.get("thinking"), "thought": LIVE.get("thought"), "rev": LIVE.get("labels_rev", 0)})
        if url.path == "/api/brief":
            return self.send_json({"brief": brief(datetime.fromisoformat(q["day"]).strftime("%Y-%m-%d"))})
        if url.path == "/api/island":  # where the island sits on screen, so the dashboard can send things home to it
            return self.send_json({"island": LIVE.get("island"), "settings": LIVE["settings"]})
        if url.path == "/api/life":  # off the clock: personal time by kind and by source
            day = datetime.fromisoformat(q["day"]).strftime("%Y-%m-%d")
            return self.send_json({**life(day), "week": life_week(day)})
        if url.path == "/api/intents":  # now, what's next (with the reason), what got done today
            return self.send_json(focus.listing())
        if url.path == "/api/range":
            d, end = datetime.fromisoformat(q["from"]), datetime.fromisoformat(q["to"])
            if not timedelta(0) <= end - d <= timedelta(days=62):
                raise ValueError("range")
            out = {}
            while d <= end:
                key = d.strftime("%Y-%m-%d")
                out[key] = day_sessions(key)
                d += timedelta(days=1)
            return self.send_json(out)
        return super().do_GET()

    def post(self):
        if self.path == "/api/edit":
            e = self.body()
            if not isinstance(e.get("id"), str):
                raise ValueError("id")
            allowed = {k: e[k] for k in ("client", "task", "billable", "status") if k in e}
            if allowed.get("status", "pending") not in STATUSES or not isinstance(allowed.get("billable", True), bool):
                raise ValueError("status")
            for k in ("client", "task"):
                if k in allowed:
                    allowed[k] = str(allowed[k])[:300]
            with lock:
                edits = load("edits.json", {})
                edits.setdefault(e["id"][:80], {}).update(allowed)
                save("edits.json", edits)
            WAKE.set()  # recount today now, so the island's numbers change as the change lands
            return self.send_json({"ok": True})
        if self.path == "/api/catch":  # something is flying from the dashboard to the island: tell it when it lands
            e, now = self.body(), time.time()
            ms = lambda k: min(3000, max(0, float(e.get(k) or 0))) / 1000
            color = e.get("color") if re.fullmatch(r"#[0-9a-fA-F]{6}", str(e.get("color"))) else "#7a7a7a"
            c = {"id": f"{now:.6f}", "text": str(e.get("text", ""))[:60], "color": color,
                 "kind": str(e.get("kind", ""))[:12], "at": now + ms("delay_ms")}
            f = e.get("flight") if isinstance(e.get("flight"), dict) else None
            if f:  # the whole path in screen coordinates, so the island can draw the part outside the browser
                pts = {k: nums(f.get(k), 4 if k == "vp" else 2) for k in ("S", "C", "I", "vp")}
                if all(pts.values()) and f.get("edge") in ("top", "bottom", "left", "right"):
                    t0 = now + ms("start_ms")
                    c["flight"] = {**pts, "t0": t0, "lift": ms("lift_ms"), "dur": max(0.05, ms("dur_ms")),
                                   "size": nums([f.get("w"), f.get("h")], 2) or [80, 30], "label": str(f.get("label", ""))[:40],
                                   "edge": f["edge"]}
                    c["at"] = t0 + c["flight"]["lift"] + c["flight"]["dur"]
            LIVE["catches"] = (LIVE.get("catches", []) + [c])[-6:]
            return self.send_json({"ok": True})
        if self.path == "/api/settings":
            e = self.body()
            out = update_settings(e)
            if "slot" in e:
                WAKE.set()  # relabel today at the new length now (if nothing today is reviewed yet)
            return self.send_json({"ok": True, "settings": out})
        if self.path == "/api/teach":  # you moved a session: what should lowkey remember from it?
            e = self.body()
            day = datetime.fromisoformat(e["day"]).strftime("%Y-%m-%d")
            return self.send_json({"hint": suggest_hint(day, str(e["id"])[:80], str(e["client"]))})
        if self.path == "/api/teach/apply":
            e = self.body()
            c = teach(str(e["client"]), str(e["hint"]), bool(e.get("forget")))
            return self.send_json({"client": c, "demo": DEMO})
        if self.path == "/api/config":  # your clients and profile, edited in the dashboard
            if DEMO:
                return self.send_json({"error": "the demo's clients are fixed; run lowkey for real to edit yours"}, 409)
            me, clients, renames = clean_config(self.body())
            save_config(me, clients)
            for old, new in renames.items():
                rename_client(old, new)
            WAKE.set()
            return self.send_json({"config": CONFIG})
        if self.path in ("/api/manual", "/api/manual/parse"):  # time you log yourself: a span picked on the timeline,
            e = self.body()                                       # or one line, "1h call with acme at 3pm"
            day = datetime.fromisoformat(e["day"]).strftime("%Y-%m-%d")
            span = (float(e["start"]) if e.get("start") is not None else None, int(e["dur_min"]) if e.get("dur_min") else None)
            try:
                if self.path == "/api/manual/parse":
                    return self.send_json(focus.entry(str(e["text"])[:200], day, *span))
                return self.send_json(add_manual(str(e["text"])[:200], day, *span))
            except ValueError as x:  # what's missing, in words the dashboard can show as is
                return self.send_json({"hint": str(x)} if self.path.endswith("parse") else {"error": str(x)}, 200 if self.path.endswith("parse") else 400)
        if self.path == "/api/manual/delete":
            delete_manual(str(self.body()["id"]))
            return self.send_json({"ok": True})
        if self.path == "/api/intents/parse":  # live chips while you type: plain parsing only, instant
            p = focus.parse(str(self.body()["text"])[:200])
            return self.send_json({**p, "reason": focus.reason({**p, "created": time.time()}, time.time()) if p["text"] else ""})
        if self.path == "/api/intents":
            e = self.body()
            return self.send_json(focus.add(str(e["text"])[:200], e.get("start") if isinstance(e.get("start"), bool) else None))
        if self.path == "/api/intents/act":
            e = self.body()
            return self.send_json(focus.act(str(e["id"]), str(e["action"]), e.get("value")))
        self.send_json({"error": "not found"}, 404)


class Server(ThreadingHTTPServer):
    # On Windows, address reuse would let a second lowkey bind the same port and track twice; there we ask for
    # the port exclusively instead, so a second copy fails fast with a clear message.
    allow_reuse_address = sys.platform != "win32"

    def server_bind(self):
        if sys.platform == "win32":
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


def make_server(port=PORT):
    return Server(("127.0.0.1", port), Handler)
